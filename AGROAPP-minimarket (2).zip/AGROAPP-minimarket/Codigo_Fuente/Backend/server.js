const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const routes = require('./routes');

const app = express();
app.use(cors());
app.use(express.json());

// Conectar a MongoDB
mongoose.connect('mongodb://localhost/tiendi', {
        useNewUrlParser: true,
        useUnifiedTopology: true,
    })
    .then(() => console.log('Conectado a la base de datos'))
    .catch((err) => console.log(err));

// Rutas
app.use('/api', routes);

// Puerto
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Servidor corriendo en el puerto ${PORT}`);
});
const authRoutes = require('./routes/auth');

app.use('/api/auth', authRoutes);
const express = require('express');
const cors = require('cors');
const app = express();
const PORT = 5000;

app.use(cors());
app.use(express.json());

app.get('/', (req, res) => {
    res.send('Servidor funcionando');
});

app.listen(PORT, () => {
    console.log(`Servidor corriendo en puerto ${PORT}`);
});


const express = require('express');
const app = express();
const cors = require('cors'); // Si es necesario para permitir solicitudes desde el frontend
const authRoutes = require('./routes/authRoutes'); // Importa las rutas

// Middleware para parsear el cuerpo de las solicitudes
app.use(express.json());
app.use(cors()); // Si lo necesitas

// Usa las rutas de autenticación
app.use('/api/auth', authRoutes); // Esto establecerá el prefijo '/api/auth' para todas las rutas de auth

// Configura el puerto
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Servidor corriendo en el puerto ${PORT}`);
});