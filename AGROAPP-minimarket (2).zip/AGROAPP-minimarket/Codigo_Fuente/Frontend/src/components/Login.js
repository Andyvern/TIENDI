import React, { useState } from 'react';
import axios from 'axios';

const Login = () => {
        const [email, setEmail] = useState('');
        const [password, setPassword] = useState('');
        const [errorMessage, setErrorMessage] = useState('');

        // Función que se ejecuta al enviar el formulario
        const handleSubmit = async(e) => {
            e.preventDefault();

            try {
                const response = await axios.post('http://localhost:5000/api/auth/login', {
                    email,
                    password,
                });

                if (response.data.token) {
                    localStorage.setItem('token', response.data.token);
                    window.location.href = '/'; // Redirige a la página principal después de login
                }
            } catch (error) {
                setErrorMessage('Correo o contraseña incorrectos');
            }
        };

        return ( <
            div >
            <
            h2 > Iniciar sesión < /h2> {
                errorMessage && < p style = {
                        { color: 'red' } } > { errorMessage } < /p>} <
                    form onSubmit = { handleSubmit } >
                    <
                    div >
                    <
                    label > Email: < /label> <
                    input
                type = "email"
                value = { email }
                onChange = {
                    (e) => setEmail(e.target.value) }
                required
                    /
                    >
                    <
                    /div> <
                    div >
                    <
                    label > Contraseña: < /label> <
                    input
                type = "password"
                value = { password }
                onChange = {
                    (e) => setPassword(e.target.value) }
                required
                    /
                    >
                    <
                    /div> <
                    button type = "submit" > Iniciar sesión < /button> <
                    /form> <
                    /div>
            );
        };

        export default Login;