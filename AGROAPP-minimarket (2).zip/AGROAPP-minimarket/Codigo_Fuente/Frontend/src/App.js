import React from 'react';
import { BrowserRouter as Router, Route, Switch } from 'react-router-dom';
import Login from './components/Login';

function App() {
    return ( <
        Router >
        <
        div >
        <
        Switch >
        <
        Route path = "/login"
        component = { Login }
        /> { /* Agrega otras rutas para tu aplicación */ } <
        /Switch> <
        /div> <
        /Router>
    );
}

export default App;