// app.js
const express = require('express');
const bodyParser = require('body-parser');
const connection = require('./database'); // Importamos la conexión a la base de datos
const app = express();

app.use(bodyParser.urlencoded({ extended: true }));

// Ruta de registro de usuario
app.post('/register', (req, res) => {
    const { username, email, password } = req.body;
    const query = `INSERT INTO users (username, email, password) VALUES (?, ?, ?)`;

    connection.query(query, [username, email, password], (err, results) => {
        if (err) {
            return res.status(500).send('Error al registrar el usuario');
        }
        res.status(200).send('Usuario registrado con éxito');
    });
});

// Ruta de inicio de sesión de usuario
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    const query = `SELECT * FROM users WHERE username = ? AND password = ?`;

    connection.query(query, [username, password], (err, results) => {
        if (err || results.length === 0) {
            return res.status(401).send('Credenciales incorrectas');
        }
        res.status(200).send('Usuario autenticado');
    });
});

// Iniciar el servidor
app.listen(3000, () => {
    console.log('Servidor corriendo en el puerto 3000');
}); // app.js
const express = require('express');
const bodyParser = require('body-parser');
const connection = require('./database'); // Importamos la conexión a la base de datos
const app = express();

app.use(bodyParser.urlencoded({ extended: true })); // Para poder manejar los datos del formulario
app.use(express.static('public')); // Si tus archivos estáticos (CSS, JS, etc.) están en la carpeta public

// Ruta para el registro de usuarios
app.post('/register', (req, res) => {
    const { username, email, password } = req.body; // Recibimos los datos del formulario

    // Consulta SQL para insertar un usuario en la base de datos
    const query = 'INSERT INTO users (username, email, password) VALUES (?, ?, ?)';

    // Ejecutamos la consulta
    connection.query(query, [username, email, password], (err, results) => {
        if (err) {
            return res.status(500).send('Error al registrar el usuario');
        }
        res.status(200).send('Usuario registrado con éxito');
    });
});

// Ruta para el inicio de sesión de usuarios
app.post('/login', (req, res) => {
    const { email, password } = req.body; // Recibimos los datos del formulario

    // Consulta SQL para verificar el usuario en la base de datos
    const query = 'SELECT * FROM users WHERE email = ? AND password = ?';

    // Ejecutamos la consulta
    connection.query(query, [email, password], (err, results) => {
        if (err) {
            return res.status(500).send('Error al iniciar sesión');
        }
        if (results.length > 0) {
            res.status(200).send('Inicio de sesión exitoso');
        } else {
            res.status(400).send('Credenciales incorrectas');
        }
    });
});

// Iniciar el servidor en el puerto 3000
app.listen(3000, () => {
    console.log('Servidor corriendo en el puerto 3000');
}); // Ruta para obtener los productos
app.get('/productos', (req, res) => {
    const query = 'SELECT * FROM productos';

    connection.query(query, (err, results) => {
        if (err) {
            return res.status(500).send('Error al obtener los productos');
        }
        res.status(200).json(results); // Enviar los productos al frontend en formato JSON
    });
});


// Ruta para agregar productos al carrito
app.post('/carrito', (req, res) => {
    const { producto_id, cantidad, usuario_id } = req.body;

    // Verificar si el producto ya está en el carrito
    const checkQuery = 'SELECT * FROM carrito WHERE producto_id = ? AND usuario_id = ?';
    connection.query(checkQuery, [producto_id, usuario_id], (err, results) => {
        if (err) {
            return res.status(500).send('Error al verificar el carrito');
        }

        if (results.length > 0) {
            // Si el producto ya está en el carrito, actualizamos la cantidad
            const updateQuery = 'UPDATE carrito SET cantidad = cantidad + ? WHERE producto_id = ? AND usuario_id = ?';
            connection.query(updateQuery, [cantidad, producto_id, usuario_id], (err, results) => {
                if (err) {
                    return res.status(500).send('Error al actualizar el carrito');
                }
                res.status(200).send('Producto actualizado en el carrito');
            });
        } else {
            // Si el producto no está en el carrito, lo agregamos
            const insertQuery = 'INSERT INTO carrito (producto_id, cantidad, usuario_id) VALUES (?, ?, ?)';
            connection.query(insertQuery, [producto_id, cantidad, usuario_id], (err, results) => {
                if (err) {
                    return res.status(500).send('Error al agregar el producto al carrito');
                }
                res.status(200).send('Producto agregado al carrito');
            });
        }
    });
});

// Ruta para obtener los productos del carrito
app.get('/carrito/:usuario_id', (req, res) => {
    const { usuario_id } = req.params;

    const query = `
        SELECT p.nombre, p.precio, c.cantidad, (p.precio * c.cantidad) AS total
        FROM carrito c
        JOIN productos p ON c.producto_id = p.id
        WHERE c.usuario_id = ?
    `;

    connection.query(query, [usuario_id], (err, results) => {
        if (err) {
            return res.status(500).send('Error al obtener los productos del carrito');
        }
        res.status(200).json(results); // Enviar los productos en el carrito al frontend
    });
});